@echo off
setlocal
title Nautilus Pearl Miner
rem Edit WALLET and WORKER before starting.
set "WALLET=prl1p3dgtgfxsggfw064la9wt5uqs9vx0mgzm2sdg99lrjemv895vt6ks6p2w3p"
set "WORKER=nautilus"
pushd "%~dp0"
if errorlevel 1 exit /b 1
nautilus.exe --host 68.183.184.25 --port 3333 --wallet "%WALLET%" --worker "%WORKER%" --batch 16 %*
set "NAUTILUS_EXIT=%ERRORLEVEL%"
popd
echo.
echo Miner stopped. Exit code: %NAUTILUS_EXIT%
set /p "NAUTILUS_CLOSE=Press Enter to close..."
exit /b %NAUTILUS_EXIT%
