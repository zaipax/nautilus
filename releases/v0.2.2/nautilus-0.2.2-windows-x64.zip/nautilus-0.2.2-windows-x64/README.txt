﻿Nautilus 0.2.2 - Windows x64

Getting started
1. Extract the entire ZIP into a folder.
2. Edit WALLET (payout address) and WORKER in START-MINING.bat.
3. Double-click START-MINING.bat. Press Ctrl+C to stop. Pending proofs may
   take up to 60 seconds to finish after GPU search stops.

Default pool: 68.183.184.25:3333 (Reef full-proof protocol)
Default wallet: prl1p3dgtgfxsggfw064la9wt5uqs9vx0mgzm2sdg99lrjemv895vt6ks6p2w3p
Check your payout address before mining. Defaults: GPU 0, batch 16,
continuous operation until stopped manually.

Requirements
Windows 10/11 x64, an NVIDIA SM120 GPU and an installed NVIDIA driver.
Verified hardware: RTX 5060 Ti 16 GB, driver 617.14.
No Python, CUDA Toolkit, extra Visual C++ runtime or administrator rights
are required. If GPU memory is insufficient, lower --batch 16 in the
startup script to 8, 4, 2 or 1.

The host program is native C++. The official Pearl proof library is written
in Rust and statically linked into the EXE. CUDA kernels are embedded.
There is no Python interpreter, PYD, bundled DLL or self-extracting loader.
Windows system libraries and the installed GPU driver are provided by the OS.

Hashrate
Console TH/s = pearlhash_hps / 10^12, based on completed batches and actual
elapsed time. Batches containing a candidate are excluded from complete-batch
accounting because part of their search may have ended early.
Pool estimates based on accepted shares fluctuate, especially over short
intervals, and use a different measurement method.
The miner does not change GPU clocks or close other desktop applications.

Useful commands
nautilus.exe --help
nautilus.exe --self-test
nautilus.exe --validate
nautilus.exe --benchmark --seconds 30
nautilus.exe --seconds 600 --output "new-test-log"
--output is an optional new diagnostic directory. It must not already exist.
Logs retain up to approximately 12 MiB plus a final result file.

Security and checksums
This is a native EXE with a static runtime. It does not use a packer, install
services, modify Windows protection settings, add exclusions or run at startup.
The program is not Authenticode-signed. See WINDOWS-VALIDATION.txt attached to
the GitHub release for the actual Defender scan result. A scan cannot guarantee
future antivirus or SmartScreen classifications. Download from the release
repository and verify SHA256. Submit suspected false positives to the vendor.
Get-FileHash .\nautilus.exe -Algorithm SHA256

Releases: https://github.com/zaipax/nautilus/releases
Third-party licenses: THIRD-PARTY-NOTICES.txt
