﻿Nautilus 0.2.1 - Windows x64

使用方法
1. 将 ZIP 完整解压到普通文件夹。
2. 编辑 START-MINING.bat 中的 WALLET（收款地址）和 WORKER（矿工名）。
3. 双击 START-MINING.bat。按 Ctrl+C 停止；正在生成的证明最多等待 60 秒。

默认矿池：68.183.184.25:3333（Reef full-proof 协议）
默认地址：prl1p3dgtgfxsggfw064la9wt5uqs9vx0mgzm2sdg99lrjemv895vt6ks6p2w3p
请核对收款地址。默认使用 GPU 0、batch 16，持续运行直到手动停止。

运行要求
Windows 10/11 x64；NVIDIA SM120 显卡及 NVIDIA 驱动。
实测硬件为 RTX 5060 Ti 16 GB，驱动 617.14。
不需要 Python、CUDA Toolkit、额外 VC 运行库安装或管理员权限。
显存不足时，可将启动脚本的 --batch 16 调低至 8、4、2 或 1。

这是原生 C++ 主程序；官方 Pearl 证明库由 Rust 编写并静态编入 EXE。
CUDA 内核已内嵌。程序没有 Python 解释器、PYD、附带 DLL 或自解压加载器。
Windows 系统库和已安装的显卡驱动仍由操作系统提供。

算力
控制台 TH/s = pearlhash_hps / 10^12，按已完成的搜索批次与实际时间计算。
含候选结果的批次不计入完整搜索量，防止把提前结束的工作量算入。
矿池短时间内按已接受 share 估算的算力存在随机波动，不能与该读数混用。
本版本不会通过设置 GPU 超频或关闭桌面程序来提高显示算力。

常用命令
nautilus.exe --help
nautilus.exe --self-test
nautilus.exe --validate
nautilus.exe --benchmark --seconds 30
nautilus.exe --seconds 600 --output "new-test-log"
--output 是可选诊断目录，必须不存在；日志最多保留约 12 MiB 加最终结果。

安全与校验
本程序为普通原生 EXE，使用静态运行库，没有加壳或安装后台服务。
不修改 Windows 防护设置，不添加排除项，不设置开机启动。
程序未进行 Authenticode 签名。Defender 的本次扫描结果见 Release 附件
WINDOWS-VALIDATION.txt；单次扫描不能保证其它版本杀软或 SmartScreen 的判定。
请从发布仓库下载并校验 SHA256，疑似误报请提交安全厂商复核。
Get-FileHash .\nautilus.exe -Algorithm SHA256

发布：https://github.com/zaipax/nautilus/releases
第三方许可见 THIRD-PARTY-NOTICES.txt。
